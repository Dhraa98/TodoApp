package com.example.todoapp.utils

class Constants {
    companion object {
        public var TASKVALUE = ""
    }
}